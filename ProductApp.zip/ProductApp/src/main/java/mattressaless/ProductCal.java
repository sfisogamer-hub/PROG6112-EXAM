/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mattressaless;

/**
 *
 * @author Student
 */
public class ProductCal implements IProductCalculations {
    
    private double productPrice;
    
    public ProductCal(double productPrice){
        this.productPrice = productPrice;
    }

    @Override
    public double getVat() {
        return productPrice * 0.15;
        
    }
    @Override
    public double getCommision() {
        return throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public double getTotal() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
