/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.products;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class Products {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        PrintProduct product1 = new PrintProduct();
        
        
        String[] productNames = {"Cozy Nights Monarch","Restonic Barbados","Sealy Phuket"};
        
        int[] totalSales = new int[9]; 
                                   
        
        for(int i = 1; i < 4;i++){
            System.out.print("Enter number of sales for month "+i+" for "+productNames[0]+" mattress: " );
            totalSales[i] = input.nextInt();
            System.out.println("The name "+totalSales[i]);
        }
        
        for (int i = 1; i < 4;i++){
            System.out.print("Enter number of sales for month "+i+" for "+productNames[1]+" mattress: " );
            totalSales[i] = input.nextInt();
            System.out.println("The name "+totalSales[i]);
        }
        for (int i = 1;i < 4;i++){
            System.out.print("Enter number of sales for month "+i+" for "+productNames[2]+" mattress: " );
            totalSales[i] = input.nextInt();
            System.out.println("The name "+totalSales[i]);
        }
        
        int total = calculateTotal(totalSales);
        double average = calculateAverage(totalSales);
        
        product1.getAverage(average);
        product1.getTotal(total);
        
        product1.displayTotals(total, average);
    }
    public static int calculateTotal(int[] totalSales){
        int sum = 0;
        for (int i = 1; i <= 9;i++){
            sum = sum + totalSales[i];
        }
        return sum;
    }
    public static double calculateAverage(int[] totalSales){
        int sum = 0;
        for (int i = 1; i <= 9;i++){
            sum = sum + totalSales[i];
        }
        double total = (double)sum / 9;
        return total;
    }
}
