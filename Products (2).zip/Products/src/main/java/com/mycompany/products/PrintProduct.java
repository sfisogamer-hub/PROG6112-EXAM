/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.products;

/**
 *
 * @author Student
 */
public class PrintProduct {
    
    private int total;
    private double average;
    
    public double getAverage(double average){
        return average;
    }
    
    public int getTotal(int total){
        return total;
    }
    
    public void displayTotals(int total,double average){
        System.out.println("PRODUCT SALES REPORT");
        System.out.println(" ");
        System.out.println("*************************************");
        System.out.println("TOTAL PRODUCT SALES: "+total);
        System.out.println("AVERAGE PRODUCT SALES: "+average);
        System.out.println("MOST POPULAR PRODUCT");
    }
}
